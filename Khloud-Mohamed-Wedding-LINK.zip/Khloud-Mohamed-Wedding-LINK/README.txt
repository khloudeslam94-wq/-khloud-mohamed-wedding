Khloud & Mohamed — Wedding Invitation

Opening:
- Natural seaside envelope image.
- Tap the envelope -> smooth fade/zoom -> FIRST invitation scene is the real moving ocean video.
- It does NOT jump to the date/details section.

Details:
- Khloud & Mohamed
- Wednesday 14 October 2026
- 5:00 PM
- Steigenberger Hotel El Lessan, Ras El Bar, Damietta

Memories:
- Includes 10 supplied couple photos in assets/photos.

Dress code:
- SEA FOAM #D1FFF2
- LAGOON #B2FFE6
- REEF WATER #8DE0D5
- TIDAL POOL #67CFC3
- DEEP CURRENT #46A3A9
- OCEAN FLOOR #237782
- Gentlemen: White + Baby Blue

Music:
The page is prepared for a legally obtained copy of “A Thousand Years” as:
assets/a-thousand-years.mp3
No copyrighted audio file is included in this package.

To publish on GitHub Pages:
Upload the CONTENTS of this folder to the repository and keep the folder structure intact.
The page entry file is index.html.
